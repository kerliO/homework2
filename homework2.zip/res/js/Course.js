class Course{
    constructor(title, semester, grade) {
        this.selected = [];
        this.title = title;
        this.semester = semester;
        this.grade = grade;
    }
}