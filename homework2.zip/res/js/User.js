class User{
    constructor(firstname, lastname, birthdate, faculty, gpa) {
        this.firstname = firstname;
        this.lastname = lastname;
        this.birthdate = birthdate;
        this.faculty = faculty;
        this.gpa = gpa;
    }
}